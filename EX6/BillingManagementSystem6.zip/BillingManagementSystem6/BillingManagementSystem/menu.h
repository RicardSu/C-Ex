#ifndef MENU_H
#define MENU_H
void outputMenu();
void add();
void query();
void logon();
void logout();
void addMoney();
void refundMoney();
void queryStatistics();
void annul();
void exitApp();

#endif