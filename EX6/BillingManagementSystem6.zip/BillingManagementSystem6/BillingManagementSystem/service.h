#ifndef SERVICE_H
#define SERVICE_H
#include"DataStruct.h"
int doLogon(const char* pName,const char* pPwd,LogonInfo *pInfo);
int doLogout(const char *pName,const char* pPwd,LogoutInfo *pInfo);
#endif