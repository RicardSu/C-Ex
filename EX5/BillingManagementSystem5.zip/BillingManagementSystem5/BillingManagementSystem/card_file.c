#include "stdio.h"
#include "stdlib.h"
#include "DataStruct.h"
#include "tool.h"
#include "global.h"

int saveCard(const Card* qCard, const char* pPath){
	FILE* fp = NULL;
	char lastTime[20] = { 0 };
	char startTime[20] = { 0 };
	char endTime[20] = { 0 };
	/*���ļ�*/
	if ((fp = fopen(pPath, "a")) == NULL){
		fp = fopen(pPath, "w");
		if (fp == NULL){
			return FALSE;
		}
	}
	timeToString(qCard->tStart, startTime);
	timeToString(qCard->tEnd, endTime);
	timeToString(qCard->tLast, lastTime);
	/*�ļ�д������*/
	fprintf(fp, "\n%s##%s##%d##%s##%s##%.1f##%s##%d##%.1f##%d\n", qCard->aName, qCard->aPwd, qCard->nStatus,startTime, endTime, qCard->fTotalUse, lastTime, qCard->nUseCount, qCard->fBalance, qCard->nDel);
	/*�ر��ļ�*/
	fclose(fp);
	return TRUE;
}

/*��������*/
Card praseCard(char* pBuf){
	Card card;
	int index = 0;
	const char *tag = "##";
	char flag[10][20] = { 0 };
	char *buf = NULL;
	char *str = NULL;
	buf = pBuf;
	while ((str = strtok(buf, tag)) != NULL){
		strcpy(flag[index], str);
		buf = NULL;
		index++;
	}
	strcpy(card.aName, flag[0]);
	strcpy(card.aPwd, flag[1]);
	card.nStatus = atoi(flag[2]);
	card.tStart = stringToTime(flag[3]);
	card.tEnd = stringToTime(flag[4]);
	card.fTotalUse = (float)atof(flag[5]);
	card.tLast = stringToTime(flag[6]);
	card.nUseCount = atoi(flag[7]);
	card.fBalance = (float)atof(flag[8]);
	card.nDel = atoi(flag[9]);
	return card;
}

/*���ؿ���Ϣ��������*/
int getCardCount(const char* pPath){
	FILE* fp = NULL;
	int nCount = 0;
	char aBuf[CARDCHARNUM] = { 0 };
	/*���ļ�����*/
	fp = fopen(pPath, "r");
	if (fp == NULL){
		return FALSE;
	}
	/*�ļ���ȡ����*/
	while (!feof(fp)){
		memset(aBuf, 0, CARDCHARNUM);
		if ((fgets(aBuf, CARDCHARNUM, fp)) != NULL){
			if (strlen(aBuf) > 0){
				nCount++;
			}
		}
	}
	/*close�ļ�*/
	fclose(fp);
	return nCount;
}

/*��ȡ��Ϣ����*/
int readCard(Card* qCard, const char* pPath){
	int i = 0;
	FILE* fp = NULL;
	char aBuf[CARDCHARNUM] = { 0 };
	fp = fopen(pPath, "r");
	if (fp == NULL){
		return FALSE;
	}
	while (!feof(fp)){
		memset(aBuf, 0, CARDCHARNUM);
		if ((fgets(aBuf, CARDCHARNUM, fp)) != NULL){
			if (strlen(aBuf) > 0){
				qCard[i] = praseCard(aBuf);
				i++;
			}
		}
	}
	fclose(fp);
	return TRUE;
}
