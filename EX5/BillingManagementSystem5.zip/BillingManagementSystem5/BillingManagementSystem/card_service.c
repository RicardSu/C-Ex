#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "card_service.h"
#include "global.h"
#include "card_file.h"

Card nCard[50];  /*����Ϣ�ṹ������*/
int nCount = 0;
lpCardNode cardList = NULL;
lpCardNode head = NULL;
lpCardNode p, q;

/*��ʼ����������*/
int initCardList() {
	head = (lpCardNode)malloc(sizeof(CardNode));
	if (head != NULL) {
		head->next = NULL;
		cardList = head;
		return TRUE;
	}
	return FALSE;
}

/*�ͷŽ�����*/
void releaseCardList()
{
	p = cardList;
	while (p != NULL) {
		q = p;
		p = p->next;
		free(q);
	}
}
int addCard(Card card) {
	return saveCard(&card, CARDPATH);
}
/*
int addCard(Card card) {
	lpCardNode fact = NULL;
	if (cardList == NULL) {
		initCardList();
	}
	//���ݱ����ڽڵ�
	fact = (lpCardNode)malloc(sizeof(CardNode));
	if (fact != NULL) {
		fact->Data = card;
		fact->next = NULL;
		//�������������һ�����
		while (cardList->next != NULL) {
			cardList = cardList->next;
		}
		cardList->next = fact;
		return TRUE;
	}
	return FALSE;
}*/

/*��ȷ��ѯ*/
Card* queryCard(const char*pName) { 
	lpCardNode fact = NULL;
	if (cardList != NULL) {
		fact = cardList->next;
		while (fact != NULL) {
			if (strcmp(fact->Data.aName, pName) == 0) {
				return &fact->Data;
			}
			fact = fact->next;
		}
	}
	return NULL;
}

/*ģ����ѯ*/
Card* queryCards(const char* pName, int*nIndex) {
	Card* qCard = NULL;
	qCard = (Card*)malloc(sizeof(Card)*nCount);
	if (getCard() == FALSE) {
		return NULL;
	}
	p = head;
	while (p!= NULL) {
		if (strstr(p->Data.aName, pName) != NULL) {
			(*nIndex)++;
			qCard = (Card *)realloc(qCard, (*nIndex) * (sizeof(Card)));
			qCard[(*nIndex - 1)] = p->Data;
		}
		p = p->next;
	}
	return qCard;
}
/*int addCard(Card card) {
	qCard[nCount] = card;
	nCount++;
	return nCount;
}*/
/*��ѯ����Ϣ����*/
/*Card* queryCard(const char* pName) {
	int i = 0;
	for (i = 0; i < nCount; i++) {
		if (strcmp(pName, qCard[i].aName) == 0) {
			return &qCard[i];
		}
		
		else {
			return NULL;

		}
	}
}*/
/*�ѿ�����Ϣ����������֮��*/
int getCard() {
	Card* qCard = NULL;
	int nCount = 0;
	int i = 0;
	p = NULL;
	q = NULL;

	if (cardList != NULL) {
		releaseCardList();
	}
	initCardList();
	nCount = getCardCount(CARDPATH);
	qCard = (Card*)malloc(sizeof(Card)*nCount);
	if (qCard == NULL) {
		return FALSE;
	}
	if (readCard(qCard, CARDPATH) == FALSE){
		free(qCard);
		qCard = NULL;
		return FALSE;
	}
	for (i = 0, p = cardList; i < nCount; i++){
		q = (lpCardNode)malloc(sizeof(CardNode));
		if (q == NULL){
			free(qCard);
			return FALSE;
		}
		memset(q, 0, sizeof(CardNode));
		q->Data = qCard[i];
		q->next = NULL;
		p->next = q;
		p = q;
	}
	return TRUE;
}

/*checkCard�������ɿ��ź������ѯ������������λ��*/
Card *checkCard(const char *pName, const char* pPwd) {
	lpCardNode cardNode = NULL;
	if (getCard() == FALSE) {
		return FALSE;
	}
	cardNode = cardList->next;
	while (cardNode != NULL) {
		if (strcmp(cardNode->Data.aName, pName) == 0 && (strcmp(cardNode->Data.aPwd, pPwd) == 0)) {
			return &cardNode->Data;
		}
		cardNode = cardNode->next;
	}
	return NULL;
}