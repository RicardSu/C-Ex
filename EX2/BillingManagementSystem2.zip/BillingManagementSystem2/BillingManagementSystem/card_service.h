#pragma once
#include "time.h"
#include "DataStruct.h"
#ifndef CARD_SERVICE_H
#define CARD_SERVICE_H

int addCard(Card card);
Card* queryCard(const char* pName);
#endif