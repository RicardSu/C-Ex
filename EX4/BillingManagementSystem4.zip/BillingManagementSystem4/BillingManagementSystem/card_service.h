#pragma once
#include "time.h"
#include "DataStruct.h"
#ifndef CARD_SERVICE_H
#define CARD_SERVICE_H

void releaseCardList();
int addCard(Card card);
Card* queryCard(const char* pName);  /*��ȷ��ѯ*/
Card* queryCards(const char* pName, int*nIndex); /*ģ����ѯ*/
#endif