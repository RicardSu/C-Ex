#define _CRT_SECURE_name_WARNINGS//����scanf����
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "card_service.h"
#include "time.h"
#include "DataStruct.h"
#include "global.h"

//Card qCard[50];  /*����Ϣ�ṹ������*/
int nCount = 0;
lpCardNode cardList = NULL;
lpCardNode head = NULL;
lpCardNode p, q;

/*��ʼ������*/
int initCardList() {
	head = (lpCardNode)malloc(sizeof(CardNode));
	if (head != NULL) {
		head->next = NULL;
		cardList = head;
		return TRUE;
	}
	return FALSE;
}

/*�ͷŽ��*/
void releaseCardList()
{
	lpCardNode fact;
	if (cardList != NULL) {
		while (cardList->next != NULL) {
			fact = cardList->next;
			free(fact);
			fact = NULL;
		}
	}
}
int addCard(Card card) {
	lpCardNode fact = NULL;
	if (cardList == NULL) {
		initCardList();
	}
	/*���ݱ����ڽڵ�*/
	fact = (lpCardNode)malloc(sizeof(CardNode));
	if (fact != NULL) {
		fact->Data = card;
		fact->next = NULL;
		/*�������������һ�����*/
		while (cardList->next != NULL) {
			cardList = cardList->next;
		}
		cardList->next = fact;
		return TRUE;
	}
	return FALSE;
}
/*��ȷ��ѯ*/
Card* queryCard(const char*pName) { 
	lpCardNode fact = NULL;
	if (cardList != NULL) {
		fact = cardList->next;
		while (fact != NULL) {
			if (strcmp(fact->Data.aName, pName) == 0) {
				return &fact->Data;
			}
			fact = fact->next;
		}
	}
	return NULL;
}

/*ģ����ѯ*/
Card* queryCards(const char* pName, int*nIndex) {
	Card* qCard = NULL;
	qCard = (Card*)malloc(sizeof(Card)*nCount);
	p = head;
	while (p!= NULL) {
		if (strstr(p->Data.aName, pName) != NULL) {
			(*nIndex)++;
			qCard = (Card *)realloc(qCard, (*nIndex) * (sizeof(Card)));
			qCard[(*nIndex - 1)] = p->Data;
		}
		p = p->next;
	}
	return qCard;
}
/*int addCard(Card card) {
	qCard[nCount] = card;
	nCount++;
	return nCount;
}*/
/*��ѯ����Ϣ����*/
/*Card* queryCard(const char* pName) {
	int i = 0;
	for (i = 0; i < nCount; i++) {
		if (strcmp(pName, qCard[i].aName) == 0) {
			return &qCard[i];
		}
		
		else {
			return NULL;

		}
	}
}*/

