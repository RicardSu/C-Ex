#pragma once
#ifndef CARD_FILE_H
#define CARD_FILE_H
#include "DataStruct.h"
int saveCard(const Card *qCard, const char* pPath);
int getCardCount(const char* pPath);
Card praseCard(char* pBuf);
int readCard(Card* qCard, const char* pPath);
#endif