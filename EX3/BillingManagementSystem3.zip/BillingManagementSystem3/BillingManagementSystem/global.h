#pragma once
#ifndef GLOBAL_H
#define GLOBAL_H
#define FALSE 0
#define TRUE 1
#define CARDPATH "data//card.txt"
#define CARDCHARNUM 256
#endif