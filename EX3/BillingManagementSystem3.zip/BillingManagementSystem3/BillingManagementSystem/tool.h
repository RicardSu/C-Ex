#pragma once
#include "time.h"
#ifndef TOOL_H
#define TOOL_H
void timeToString(time_t t, char* pBuf);
time_t stringToTime(char* pTime);
#endif